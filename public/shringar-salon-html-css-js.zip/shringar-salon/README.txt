Shringar Unisex Salon & Makeup Studio — Standalone HTML, CSS & JS Package

How to use & share:
1. Extract this folder anywhere.
2. Double-click index.html to open directly in any browser, OR open the folder in VS Code (Live Server) / deploy to Netlify, Vercel, or GitHub Pages.
3. To change the WhatsApp booking number, edit SALON_WHATSAPP_NUMBER and SALON_WHATSAPP_DISPLAY at the bottom of js/data.js.
